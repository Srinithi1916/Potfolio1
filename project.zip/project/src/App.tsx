import React from 'react';
import { Header } from './components/Header/Header';
import { PersonalInfo } from './components/PersonalInfo/PersonalInfo';
import { Projects } from './components/Projects/Projects';
import { About } from './components/About/About';
import { ContactForm } from './components/Contact/ContactForm';

function App() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <main className="container mx-auto py-8 px-4">
        <PersonalInfo />
        <About />
        <Projects />
        <ContactForm />
      </main>
    </div>
  );
}

export default App;
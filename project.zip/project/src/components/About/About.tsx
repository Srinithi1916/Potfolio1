import React from 'react';

export function About() {
  return (
    <section className="bg-white p-8 rounded-lg shadow-md mb-8">
      <h2 className="text-2xl font-semibold mb-4">About Me</h2>
      <div className="prose">
        <p className="text-gray-600 mb-4">
          I am a passionate software developer with expertise in web development and problem-solving.
          Currently pursuing my education at SKCET, I focus on creating efficient and scalable solutions.
        </p>
        <div className="flex gap-4">
          <a 
            href="/resume.pdf" 
            download
            className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition-colors inline-flex items-center"
          >
            Download Resume
          </a>
        </div>
      </div>
    </section>
  );
}
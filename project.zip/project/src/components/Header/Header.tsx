import React from 'react';
import { ContactLinks } from '../ContactLinks/ContactLinks';

export function Header() {
  return (
    <header className="bg-white p-8 shadow-sm">
      <h1 className="text-3xl font-bold mb-4">Portfolio</h1>
      <ContactLinks />
    </header>
  );
}
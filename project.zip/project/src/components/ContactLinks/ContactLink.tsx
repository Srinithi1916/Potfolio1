import React from 'react';

interface ContactLinkProps {
  url: string;
  label: string;
}

export function ContactLink({ url, label }: ContactLinkProps) {
  return (
    <a 
      href={url}
      target="_blank"
      rel="noopener noreferrer"
      className="text-blue-600 hover:text-blue-800 transition-colors"
    >
      {label}
    </a>
  );
}
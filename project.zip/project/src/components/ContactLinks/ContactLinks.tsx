import React from 'react';
import { ContactLink } from './ContactLink';

export function ContactLinks() {
  const links = [
    {
      url: 'https://www.codechef.com/users/srinithisrinit',
      label: 'CodeChef'
    },
    {
      url: 'https://leetcode.com/u/srinithisrinithi09/',
      label: 'LeetCode'
    },
    {
      url: 'https://github.com/Srinithi1916',
      label: 'GitHub'
    }
  ];

  return (
    <div className="flex flex-col gap-2">
      {links.map((link) => (
        <ContactLink 
          key={link.url}
          url={link.url}
          label={link.label}
        />
      ))}
    </div>
  );
}
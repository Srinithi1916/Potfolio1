import React from 'react';

interface ProjectCardProps {
  title: string;
  url: string;
  description: string;
}

export function ProjectCard({ title, url, description }: ProjectCardProps) {
  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h3 className="text-xl font-semibold mb-2">{title}</h3>
      <p className="text-gray-600 mb-4">{description}</p>
      <a 
        href={url}
        target="_blank"
        rel="noopener noreferrer"
        className="text-blue-600 hover:text-blue-800 transition-colors"
      >
        View Project →
      </a>
    </div>
  );
}
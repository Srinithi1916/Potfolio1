import React from 'react';
import { ProjectCard } from './ProjectCard';

export function Projects() {
  const projects = [
    {
      title: 'Project Home',
      url: 'https://projecthome.onrender.com/',
      description: 'A web application for home management'
    },
    {
      title: 'Presentation React Project',
      url: 'https://presentationreactproject.onrender.com',
      description: 'Interactive presentation platform built with React'
    }
  ];

  return (
    <section className="p-8">
      <h2 className="text-2xl font-semibold mb-6">Projects</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {projects.map((project) => (
          <ProjectCard 
            key={project.url}
            {...project}
          />
        ))}
      </div>
    </section>
  );
}
import React from 'react';

export function PersonalInfo() {
  return (
    <section className="bg-white p-8 rounded-lg shadow-md mb-8">
      <h2 className="text-2xl font-semibold mb-4">Personal Information</h2>
      <div className="space-y-2">
        <p className="text-gray-600">
          <span className="font-medium">Name:</span> Srinithi
        </p>
        <p className="text-gray-600">
          <span className="font-medium">Email:</span> 727722euit184@skcet.ac.in
        </p>
        <p className="text-gray-600">
          <span className="font-medium">Education:</span> Sri Krishna College of Engineering and Technology
        </p>
        <p className="text-gray-600">
          <span className="font-medium">Department:</span> B.Tech Information Technology
        </p>
      </div>
    </section>
  );
}